<?php
/**
 * Plugin Name: Elementor Nex Widget
 * Description: Nex widget for Elementor.
 * Plugin URI:  https://elementor.com/
 * Version:     1.0.0
 * Author:      Elementor Developer
 * Author URI:  https://developers.elementor.com/
 * Text Domain: elementor-nex-widget
 *
 * Requires Plugins: elementor
 * Elementor tested up to: 3.25.0
 * Elementor Pro tested up to: 3.25.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Register Nex Widget.
 *
 * Include widget file and register widget class.
 *
 * @since 1.0.0
 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
 * @return void
 */
function register_nex_widget( $widgets_manager ) {

	require_once( __DIR__ . '/widgets/nex-widget.php' );

	$widgets_manager->register( new \Elementor_Nex_Widget() );

}
add_action( 'elementor/widgets/register', 'register_nex_widget' );



function register_nex_widget_styles() {
    wp_register_style( 'nex-widget-style', plugins_url( 'assets/css/style.css', __FILE__ ) );
}
add_action( 'wp_enqueue_scripts', 'register_nex_widget_styles' );

