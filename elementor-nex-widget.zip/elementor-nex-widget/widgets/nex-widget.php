<?php


use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor Nex Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Elementor_Nex_Widget extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Nex widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget name.
	 */
	public function get_name(): string {
		return 'Nex';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Nex widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget title.
	 */
	public function get_title(): string {
		return esc_html__( 'Nex', 'elementor-nex-widget' );
	}

	public function get_style_depends() {
	    return [ 'nex-widget-style' ];
	}


	/**
	 * Get widget icon.
	 *
	 * Retrieve list widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget icon.
	 */
	public function get_icon(): string {
		return 'eicon-slider-vertical';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the list widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget categories.
	 */
	public function get_categories(): array {
		return [ 'general' ];
	}

	/**
	 * Get widget keywords.
	 *
	 * Retrieve the list of keywords the list widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return array Widget keywords.
	 */
	public function get_keywords(): array {
		return [ 'nex', 'slider', 'vertical', 'sticky' ];
	}

	/**
	 * Get custom help URL.
	 *
	 * Retrieve a URL where the user can get more information about the widget.
	 *
	 * @since 1.0.0
	 * @access public
	 * @return string Widget help URL.
	 */
	public function get_custom_help_url(): string {
		return 'https://developers.elementor.com/docs/widgets/';
	}



	/**
	 * Whether the widget requires inner wrapper.
	 *
	 * Determine whether to optimize the DOM size.
	 *
	 * @since 1.0.0
	 * @access protected
	 * @return bool Whether to optimize the DOM size.
	 */
	public function has_widget_inner_wrapper(): bool {
		return false;
	}

	/**
	 * Register list widget controls.
	 *
	 * Add input fields to allow the user to customize the widget settings.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function _register_controls() {
   		 // Section: Static Content
	    $this->start_controls_section(
	        'static_content_section',
	        [
	            'label' => __( 'Static Content', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_CONTENT,
	        ]
	    );

	    $this->add_control(
	        'static_title',
	        [
	            'label' => __( 'Main Title', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXT,
	            'default' => __( 'Main Section Title', 'elementor-nex-widget' ),
	        ]
	    );

	    $this->add_control(
	        'static_sub',
	        [
	            'label' => __( 'Sub Title', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXT,
	            'default' => __( 'Sub Section Title', 'elementor-nex-widget' ),
	        ]
	    );

	    $this->add_control(
	        'static_text',
	        [
	            'label' => __( 'Main Description', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXTAREA,
	            'default' => __( 'This is the main paragraph description.', 'elementor-nex-widget' ),
	        ]
	    );

	    $this->add_control(
	        'static_button_text',
	        [
	            'label' => __( 'Button Text', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXT,
	            'default' => __( 'Click Here', 'elementor-nex-widget' ),
	        ]
	    );

	    $this->add_control(
	        'static_button_link',
	        [
	            'label' => __( 'Button Link', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::URL,
	            'placeholder' => __( 'https://your-link.com', 'elementor-nex-widget' ),
	        ]
	    );

	    $this->end_controls_section();

	    // Section: Repeater List
	    $this->start_controls_section(
	        'repeater_section',
	        [
	            'label' => __( 'Nex Items', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_CONTENT,
	        ]
	    );

	    $repeater = new Repeater();

	    $repeater->add_control(
	        'nex_image',
	        [
	            'label' => __( 'Nex Image', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::MEDIA,
	            'default' => [
	                'url' => Elementor\Utils::get_placeholder_image_src(),
	            ],
	        ]
	    );

	    $repeater->add_control(
	        'nex_title',
	        [
	            'label' => __( 'Nex Title', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXT,
	            'default' => __( 'List Item Title', 'elementor-nex-widget' ),
	        ]
	    );

	    $repeater->add_control(
	        'nex_text',
	        [
	            'label' => __( 'Nex Text', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::TEXTAREA,
	            'default' => __( 'This is a list item description.', 'elementor-nex-widget' ),
	        ]
	    );

	    $repeater->add_control(
	        'nex_icon',
	        [
	            'label' => __( 'Choose Icon', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::ICONS,
	            'default' => [
	                'value' => 'fas fa-check', // Default Font Awesome Icon
	                'library' => 'fa-solid',  // Font Awesome solid icons
	            ],
	        ]
	    );

	    $this->add_control(
	        'nex_items',
	        [
	            'label' => __( 'Nex Items', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::REPEATER,
	            'fields' => $repeater->get_controls(),
	            'title_field' => '{{{ nex_title }}}',
	        ]
	    );

	    $this->end_controls_section();

	    // Style Tab: Title & Text
	    $this->start_controls_section(
	        'style_title_section',
	        [
	            'label' => __( 'Title & Text', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_STYLE,
	        ]
	    );

	    $this->add_control(
	        'title_color',
	        [
	            'label' => __( 'Title Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .fl-rich-text h2' => 'color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_control(
	        'subtitle_color',
	        [
	            'label' => __( 'Sub Title Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .nex_left_heading h5.vamtam-heading' => 'color: {{VALUE}};', // Corrected selector
	            ],
	        ]
	    );

	    $this->add_control(
	        'text_color',
	        [
	            'label' => __( 'All Text Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .fl-rich-text p' => 'color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'sub_title_typography',
	            'label' => __( 'Sub Title Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .fl-module-vamtam-heading h5.vamtam-heading',
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'title_typography',
	            'label' => __( 'Title Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .fl-rich-text h2',
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'text_typography',
	            'label' => __( 'All Text Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .fl-rich-text p',
	        ]
	    );

	    $this->end_controls_section();

	    // Style Tab: Button
	    $this->start_controls_section(
	        'style_button_section',
	        [
	            'label' => __( 'Button', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_STYLE,
	        ]
	    );

	    $this->add_control(
	        'button_color',
	        [
	            'label' => __( 'Button Text Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .vamtam-button.accent5.button-solid' => 'color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_control(
	        'button_bg_color',
	        [
	            'label' => __( 'Button Background Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .vamtam-button.accent5.button-solid' => 'background-color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'button_typography',
	            'label' => __( 'Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .vamtam-button.accent5.button-solid',
	        ]
	    );

	    $this->end_controls_section();



	    // Style Tab: Icon
	    $this->start_controls_section(
	        'style_icon_section',
	        [
	            'label' => __( 'Icon', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_STYLE,
	        ]
	    );

	    $this->add_control(
	        'icon_color',
	        [
	            'label' => __( 'Icon Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .fl-module-content .fl-icon i' => 'color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'icon_typography',
	            'label' => __( 'Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .fl-module-content .fl-icon i',
	        ]
	    );

	    $this->end_controls_section();


	    // List Title Tab: Icon
	    $this->start_controls_section(
	        'style_list_section',
	        [
	            'label' => __( 'List Title', 'elementor-nex-widget' ),
	            'tab' => Controls_Manager::TAB_STYLE,
	        ]
	    );

	    $this->add_control(
	        'list_color',
	        [
	            'label' => __( 'List Title Color', 'elementor-nex-widget' ),
	            'type' => Controls_Manager::COLOR,
	            'selectors' => [
	                '{{WRAPPER}} .fl-module-vamtam-heading h4.vamtam-heading' => 'color: {{VALUE}};',
	            ],
	        ]
	    );

	    $this->add_group_control(
	        Group_Control_Typography::get_type(),
	        [
	            'name' => 'list_typography',
	            'label' => __( 'Typography', 'elementor-nex-widget' ),
	            'selector' => '{{WRAPPER}} .fl-module-vamtam-heading h4.vamtam-heading',
	        ]
	    );

	    $this->end_controls_section();
	}


    protected function render() {
        $settings = $this->get_settings_for_display();


		echo '<div class="fl-row fl-row-full-width fl-row-bg-color nex_section fl-row-default-height fl-row-align-center fl-row-bg-attachment-scroll vamtam-animation-inside vamtam-pin-inside">
				<div class="fl-row-content-wrap vamtam-show-bg-image">
					<div class="fl-row-content fl-row-fixed-width fl-node-content">

						<div class="fl-col-group nex_main fl-col-group-custom-width">
							<div class="fl-col nex_main_col fl-col-bg-color fl-col-small fl-col-small-custom-width fl-col-has-cols">
								<div class="fl-col-content fl-node-content vamtam-show-bg-image">
									<div class="fl-col-group nex_sub_col fl-col-group-nested fl-col-group-custom-width" style="position: relative;">
										<div class="vamtam-pin-pusher fl-col nex_sub_content" style="width: 516px; height: 2356px;">
											<div class="vamtam-pin-wrapper vamtam-pin-active" style="will-change: transform, position; height: 519px; top: 218px;">
												<div class="fl-col nex_sub_content fl-col-bg-none fl-col-small-custom-width" style="transform-origin: center center 0px; width: 100%; opacity: 1;">
													<div class="fl-col-content fl-node-content vamtam-show-bg-image">
														<div class="fl-module fl-module-vamtam-heading nex_left_heading">
																<div class="fl-module-content fl-node-content">
																	<h5 class="vamtam-heading ">
																		<span class="vamtam-heading-text">' . esc_html( $settings['static_sub'] ) . '</span>
																	</h5>
																</div>
														</div>
														<div class="fl-module fl-module-rich-text nex_left_main_heading">
															<div class="fl-module-content fl-node-content">
																<div class="fl-rich-text">
																	<h2> ' . esc_html( $settings['static_title'] ) . '</h2>
																</div>
															</div>
														</div>
														<div class="fl-module fl-module-rich-text nex_left_text">
															<div class="fl-module-content fl-node-content">
																<div class="fl-rich-text">
																	<p>' . esc_html( $settings['static_text'] ) . '</p>
																</div>
															</div>
														</div>
														<div class="fl-module fl-module-vamtam-button nex_left_link" style="transform-origin: center center 0px; translate: none; rotate: none; scale: none; opacity: 1; transform: translate3d(0px, 83.5135px, 0px);">
															<div class="fl-module-content fl-node-content">
																<div class="vamtam-button-wrap vamtam-button-width-auto" style="text-align:left">
																<a href="' . esc_url( $settings['static_button_link']['url'] ) . '" target="_self" class="vamtam-button accent5 hover-accent1 button-solid icon-animation-disable" role="button" style="font-size:16px;line-height:18px;padding:16px 32px;">
																				<span class="vamtam-button-text">' . esc_html( $settings['static_button_text'] ) . '</span>
																	</a>
																</div>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>	
							</div>
							<div class="fl-col nex_right_col fl-col-bg-none fl-col-small-custom-width fl-col-has-cols">
								<div class="fl-col-content fl-node-content vamtam-show-bg-image">';


									if ( ! empty( $settings['nex_items'] ) ) {
										foreach ( $settings['nex_items'] as $item ) {
											echo '<div class="fl-col-group nex_right_sub_col fl-col-group-nested fl-col-group-custom-width">
														<div class="fl-col fl-node-599be884d9e29 fl-col-bg-photo fl-col-small-custom-width vamtam-hide-bg-photo-mobile fl-col-bg-fixed" >';
															if ( ! empty( $item['nex_image']['url'] ) ) {
														        echo '<div class="fl-col-content fl-node-content vamtam-show-bg-image" style="background-image: url(' . esc_url( $item['nex_image']['url'] ) .')">';
														    }
															echo '<div class="fl-module fl-module-vamtam-icon nex_right_content" style="transform-origin: center center 0px; translate: none; rotate: none; scale: none; transform: translate3d(0px, 0px, 0px) scale(0.5365); opacity: 0.5365;">
																	<div class="fl-module-content fl-node-content">
																		<span class="fl-icon-wrap">
																			<span class="fl-icon">';
																				// Display Icon if selected
																		        if ( ! empty( $item['nex_icon']['value'] ) ) {
																		            echo '<i class="' . esc_attr( $item['nex_icon']['value'] ) . '"></i> ';
																		        }
																			echo '</span>
																		</span>
																	</div>
																</div>
																<div class="fl-module fl-module-vamtam-heading nex_right_heading" data-node="599be884d9fd9">
																	<div class="fl-module-content fl-node-content">
																		<h4 class="vamtam-heading ">';
																			// Display Title if not empty
																	        if ( ! empty( $item['nex_title'] ) ) {
																	            echo '<span class="vamtam-heading-text">' . esc_html( $item['nex_title'] ) . ':</span> ';
																	        }
																		echo '</h4>
																	</div>
																</div>
																<div class="fl-module fl-module-rich-text nex_right_text">
																	<div class="fl-module-content fl-node-content">
																		<div class="fl-rich-text"><p style="text-align: center;">';
																			// Display Description if not empty
																	        if ( ! empty( $item['nex_text'] ) ) {
																	            echo esc_html( $item['nex_text'] );
																	        }
																		echo '</p></div>
																	</div>
																</div>
															</div>
														</div>
													</div>';

										}	
									}
									
	
						echo '</div>
					</div>
				</div>
			</div>
		</div>
	</div>';

    }

}
